package com.example.demo.service;

public interface AiService {
    public String chat(String question);
    public String chat(String imgUrl ,String question);
}
